package com.example.quotegenerator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    TextView tvQuote, tvAuthor;
    Button btnNewQuote;

    // Sample quotes
    String[][] quotes = {
            {"The best way to get started is to quit talking and begin doing.", "Walt Disney"},
            {"Don’t let yesterday take up too much of today.", "Will Rogers"},
            {"It’s not whether you get knocked down, it’s whether you get up.", "Vince Lombardi"},
            {"If you are working on something exciting, it will keep you motivated.", "Steve Jobs"},
            {"Success is not in what you have, but who you are.", "Bo Bennett"}
    };

    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvQuote = findViewById(R.id.tvQuote);
        tvAuthor = findViewById(R.id.tvAuthor);
        btnNewQuote = findViewById(R.id.btnNewQuote);

        // Show a random quote on start
        showRandomQuote();

        // Button click to show new quote
        btnNewQuote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showRandomQuote();
            }
        });
    }

    private void showRandomQuote() {
        int index = random.nextInt(quotes.length);
        tvQuote.setText("\"" + quotes[index][0] + "\"");
        tvAuthor.setText("- " + quotes[index][1]);
    }
}
