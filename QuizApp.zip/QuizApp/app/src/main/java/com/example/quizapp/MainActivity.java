package com.example.quizapp;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;



import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView tvIndex, tvContent;
    private Button btnPrev, btnNext, btnShowAnswer, btnEdit, btnDelete;
    private FloatingActionButton fabAdd;

    private ArrayList<Flashcard> flashcards;
    private int currentIndex = 0;
    private boolean showingAnswer = false;

    private static final String PREFS = "FLASH_PREFS";
    private static final String KEY_FLASH = "FLASH_LIST";
    private SharedPreferences prefs;
    private Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // restore state if rotated
        if (savedInstanceState != null) {
            currentIndex = savedInstanceState.getInt("currentIndex", 0);
            showingAnswer = savedInstanceState.getBoolean("showingAnswer", false);
        }

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        tvIndex = findViewById(R.id.tvIndex);
        tvContent = findViewById(R.id.tvContent);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        btnShowAnswer = findViewById(R.id.btnShowAnswer);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);
        fabAdd = findViewById(R.id.fabAdd);

        loadFlashcards();

        // If no cards, add a couple sample cards for first run
        if (flashcards.isEmpty()) {
            flashcards.add(new Flashcard("What is the capital of France?", "Paris"));
            flashcards.add(new Flashcard("What is 2 + 2?", "4"));
            saveFlashcards();
        }

        updateUI();

        btnShowAnswer.setOnClickListener(v -> {
            if (flashcards.isEmpty()) return;
            showingAnswer = !showingAnswer;
            updateCardText();
            btnShowAnswer.setText(showingAnswer ? "Show Question" : "Show Answer");
        });

        btnPrev.setOnClickListener(v -> {
            if (flashcards.isEmpty()) return;
            currentIndex = (currentIndex - 1 + flashcards.size()) % flashcards.size();
            showingAnswer = false;
            updateUI();
        });

        btnNext.setOnClickListener(v -> {
            if (flashcards.isEmpty()) return;
            currentIndex = (currentIndex + 1) % flashcards.size();
            showingAnswer = false;
            updateUI();
        });

        fabAdd.setOnClickListener(v -> openAddEditDialog(-1));

        btnEdit.setOnClickListener(v -> {
            if (flashcards.isEmpty()) return;
            openAddEditDialog(currentIndex);
        });

        btnDelete.setOnClickListener(v -> {
            if (flashcards.isEmpty()) return;
            new AlertDialog.Builder(this)
                    .setTitle("Delete flashcard")
                    .setMessage("Are you sure you want to delete this flashcard?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        flashcards.remove(currentIndex);
                        if (flashcards.isEmpty()) {
                            currentIndex = 0;
                        } else {
                            currentIndex = currentIndex % flashcards.size();
                        }
                        saveFlashcards();
                        showingAnswer = false;
                        updateUI();
                        Toast.makeText(MainActivity.this, "Deleted", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

    }

    private void openAddEditDialog(int indexToEdit) {
        boolean isEdit = indexToEdit >= 0;
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.dialog_add_edit, null);
        EditText etQuestion = view.findViewById(R.id.etQuestion);
        EditText etAnswer = view.findViewById(R.id.etAnswer);

        if (isEdit) {
            Flashcard f = flashcards.get(indexToEdit);
            etQuestion.setText(f.question);
            etAnswer.setText(f.answer);
        }

        new AlertDialog.Builder(this)
                .setTitle(isEdit ? "Edit Flashcard" : "Add Flashcard")
                .setView(view)
                .setPositiveButton(isEdit ? "Save" : "Add", (dialog, which) -> {
                    String q = etQuestion.getText().toString().trim();
                    String a = etAnswer.getText().toString().trim();
                    if (q.isEmpty() || a.isEmpty()) {
                        Toast.makeText(this, "Question and answer cannot be empty", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (isEdit) {
                        Flashcard f = flashcards.get(indexToEdit);
                        f.question = q;
                        f.answer = a;
                        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
                    } else {
                        flashcards.add(new Flashcard(q, a));
                        currentIndex = flashcards.size() - 1; // show new card
                        Toast.makeText(this, "Added", Toast.LENGTH_SHORT).show();
                    }
                    showingAnswer = false;
                    saveFlashcards();
                    updateUI();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void updateUI() {
        if (flashcards.isEmpty()) {
            tvIndex.setText("0 / 0");
            tvContent.setText("No flashcards yet.\nTap + to add one.");
            btnPrev.setEnabled(false);
            btnNext.setEnabled(false);
            btnShowAnswer.setEnabled(false);
            btnEdit.setEnabled(false);
            btnDelete.setEnabled(false);
            btnShowAnswer.setText("Show Answer");
        } else {
            tvIndex.setText((currentIndex + 1) + " / " + flashcards.size());
            btnPrev.setEnabled(true);
            btnNext.setEnabled(true);
            btnShowAnswer.setEnabled(true);
            btnEdit.setEnabled(true);
            btnDelete.setEnabled(true);
            btnShowAnswer.setText(showingAnswer ? "Show Question" : "Show Answer");
            updateCardText();
        }
    }

    private void updateCardText() {
        if (flashcards.isEmpty()) return;
        Flashcard f = flashcards.get(currentIndex);
        tvContent.setText(showingAnswer ? f.answer : f.question);
    }

    private void saveFlashcards() {
        String json = gson.toJson(flashcards);
        prefs.edit().putString(KEY_FLASH, json).apply();
    }

    private void loadFlashcards() {
        String json = prefs.getString(KEY_FLASH, null);
        if (json == null) {
            flashcards = new ArrayList<>();
            return;
        }
        Type type = new TypeToken<ArrayList<Flashcard>>() {}.getType();
        flashcards = gson.fromJson(json, type);
        if (flashcards == null) flashcards = new ArrayList<>();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("currentIndex", currentIndex);
        outState.putBoolean("showingAnswer", showingAnswer);
    }
}
